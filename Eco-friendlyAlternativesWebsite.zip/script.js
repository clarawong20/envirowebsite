//This will bring the popup window
function basicPopup(url) {
  popupWindow = window.open(url,'popUpWindow','height=500,width=800,left=50,top=50,resizable=yes,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no, status=yes')
}
